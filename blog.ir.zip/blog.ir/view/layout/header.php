<!DOCTYPE HTML>
<!--
	Future Imperfect by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html dir="">
<style>
    *{
        letter-spacing:0px !important
    }
</style>
<head>
    <title>یک وبلاگ دیگر توسط من</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="public/template/assets/css/main.css" />
    <link rel="stylesheet" href="public/template/rtl/rtl.css"/>

    <link href='http://www.fontonline.ir/css/BZiba.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BYekan.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BYas.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BShiraz.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BMorvarid.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BDavat.css' rel='stylesheet' type='text/css'>
    <link href='http://www.fontonline.ir/css/BNazanin.css' rel='stylesheet' type='text/css'>


    <!--'BZiba'-->
    <!--'BYekan'-->
    <!--'BYas'-->

</head>
<body class="is-preload">

<!-- Wrapper -->
<div id="wrapper">

    <!-- Header -->
    <header id="header">
        <h1><a href="index.html">یک وبلاگ ساده</a></h1>
        <nav class="links">
            <ul>
                <li><a href="">منوی ۱</a></li>
                <li><a href="#">منوی ۲</a></li>
                <li><a href="#">منوی ۳</a></li>
                <li><a href="#">منوی ۴</a></li>
                <li><a href="#">منوی ۵</a></li>
            </ul>
        </nav>
        <nav class="main">
            <ul>
                <li class="search">
                    <a class="fa-search" href="#search">جستجو</a>
                    <form id="search" method="get" action="#">
                        <input type="text" name="query" placeholder="Search" />
                    </form>
                </li>

            </ul>
        </nav>
    </header>