<script
        src="http://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
<style>
    .b3 {
        margin: 0 auto !important;
    }
</style>
<div class="col-md-2"></div>
<center>
    <div class="col-md-8"><br><br>

        <div class="box box-info b3">
            <div class="box-header with-border">
                <h3 class="box-title">افزودن دسته بندی</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
                <div class="box-body">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">عنوان</label>

                        <div class="col-sm-10">
                            <input name="frm[title]" type="text" class="form-control" id="title" placeholder="عنوان"
                                   required>
                        </div>
                    </div>

                </div>
                <!-- /.box-body -->
                <div style="    display: flex;
    justify-content: center;" class="box-footer">
                    <button style="
padding:5px 20px;font-size: 19px" type="submit" class="btn btn-info pull-right">افزودن
                    </button>
                </div>
                <!-- /.box-footer -->
            </form>
        </div>

    </div>
