<?php
$po=$_GET['id'];
delectshop($po);
header("location:dashbord.php?m=btn&p=list");