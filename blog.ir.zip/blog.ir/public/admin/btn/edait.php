<?php
if (isset($_POST['btn'])) {
//    $to = uploader_icons('../admin/images/icons', 'icons');
    okedaitbtn($_POST['from'],$_GET['id']);
}
$btn=showedaitbtn($_GET['id']);
?>
<div class="box box-info">
    <h6 class="box-title">توجه:هاور دکمه ها همان مقدار رنگ فعلی با شفافیت کمتر است </h6>

    <div class="box-header with-border">
        <h3 class="box-title">افزودن دکمه</h3>
    </div>

    <style>
        .box {
            width: 60%;
        }
    </style>
    <!-- /.box-header -->
    <!-- form start -->
    <form class="form-horizontal" method="post" enctype="multipart/form-data">
        <div class="box-body ">
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 col-lg-2 control-label">عنوان دکمه</label>

                <div class="col-sm-10">
                    <input value="<?php echo $btn['title']?>" type="text" name="from[title]" class="form-control col-lg-10" id="inputEmail3" required
                           placeholder="عنوان">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 col-lg-2 control-label">آدرس دکمه</label>

                <div class="col-sm-10">
                    <input value="<?php echo $btn['link']?>" type="text" name="from[url]" class="form-control col-lg-10" id="inputPassword3" required
                           placeholder="آدرس دکمه">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 col-lg-2 control-label">دسته بندی</label>

                <div class="col-sm-10">
                    <?php
                    //                    $show = add_submenu();
                    ?>
                    <select class="col-lg-10" name="from[grid]" required>
                        <option value="0" <?php
                        if($btn['grid']=='0'){
                            echo  ' selected';
                        }
                        ?>>ناحیه1 </option>
                        <option value="1" <?php
                        if($btn['grid']=='1'){
                            echo  ' selected';
                        }
                        ?>>ناحیه2 </option>
                        <option value="2" <?php
                        if($btn['grid']=='2'){
                            echo  ' selected';
                        }
                        ?>>ناحیه3 </option>
                        <option value="3" <?php
                        if($btn['grid']=='3'){
                            echo  ' selected';
                        }
                        ?>>ناحیه4 </option>

                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 col-lg-2 control-label">ترتیب نمایش</label>

                <div class="col-sm-10">
                    <input value="<?php
                    echo $btn['sort']
                    ?>" name="from[sort]" required type="number" class="form-control col-lg-4" id="inputPassword3"
                           placeholder="ترتیب نمایش">
                </div>
            </div>


            <div class="form-group">

                <div class="col-lg-10 col-sm-10"><br>
                    <label for="">انتخاب رنگ دکمه</label>
                    <div class="radio">
                        <label><input value="<?php
                            echo $btn['color']
                            ?>" required name="from[color]" type="color"></label>
                    </div>


                </div>
                <div class="col-lg-10 col-sm-10"><br>
                    <label for="">انتخاب رنگ بردر</label>
                    <div class="radio">
                        <label><input value="<?php
                            echo $btn['border']
                            ?>" required name="from[border]" type="color"></label>
                    </div>


                </div>
            </div>
        </div>
        <div class="box-footer">
            <button type="submit" name="btn" class="btn btn-info pull-right">ذخیره</button>
        </div>
</div>
<!-- /.box-body -->

<!-- /.box-footer -->
</form>
</div>