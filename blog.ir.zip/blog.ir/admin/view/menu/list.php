<br><br>
<div class="col-xs-12">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">نمایش لیست منو ها</h3>
            <style>
                input{
                    width: 130px !important;
                }
                td{
                    padding: 12px !important;
                }
            </style>

        </div>
        <!-- /.box-header -->
        <div class="box-body table-responsive no-padding">
            <table class="table table-hover">
                <tbody><tr>
                    <th>عنوان</th>
                    <th>آدرس</th>
                    <th>وضعیت نمایش</th>
                    <th>ترتیب نمایش</th>
                    <th>ویرایش</th>
                    <th>حذف</th>

                </tr>
                <tr>
                    <td>منوی ۱</td>
                    <td>‌<input width="70px !important" type="text" value="blog.ir"></td>
                    <td> <span class="label label-success">فعال</span></td>
                    <td><span class="label label-info">5</span></td>
                    <td ><span class="label label-warning">ویرایش</span></td>
                    <td ><span class="label label-danger">حذف</span></td>

                </tr>
                <tr>
                    <td>منوی 2</td>
                    <td>‌<input width="70px" type="text" value="blog.ir"></td>
                    <td> <span class="label label-success">فعال</span></td>
                    <td><span class="label label-info">5</span></td>
                    <td ><span class="label label-warning">ویرایش</span></td>
                    <td ><span class="label label-danger">حذف</span></td>
                </tr>
                <tr>
                    <td>منوی ۳</td>
                    <td>‌<input width="70px" type="text" value="blog.ir"></td>
                    <td> <span class="label label-danger"> غیر فعال</span></td>
                    <td><span class="label label-info">5</span></td>
                    <td ><span class="label label-warning">ویرایش</span></td>
                    <td ><span class="label label-danger">حذف</span></td>
                </tr>
                <tr>
                    <td>‌ منوی ۳</td>
                    <td>‌<input width="70px" type="text" value="blog.ir"></td>

                    <td> <span class="label label-success">فعال</span></td>
                    <td><span class="label label-info">5</span></td>
                    <td ><span class="label label-warning">ویرایش</span></td>
                    <td ><span class="label label-danger">حذف</span></td>
                </tr>
                </tbody></table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>