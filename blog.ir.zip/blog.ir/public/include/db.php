<?php
class db  {
    public $pdo;
    private $user;
    private $server;
    private $password;
    private $db;
    private $tbl;
    public function __construct($db='blog.ir',$server='localhost',$user='root',$password='')
    {
$this->db=$db;
$this->user=$user;
$this->server=$server;
$this->db=$db;
$this->conect();
    }
    public function conect(){
        $this->pdo=new PDO("mysql:host=$this->server;dbname=$this->db","$this->user",'');

    }
}
?>