<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style_login.css">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- login div -->
<div class="login">
    <!-- login header -->
    <h1 id="header">ورود به پیشخوان </h1>
    <!-- start da login goodness -->
    <form id="form" method="post" >
        <input name="form[username]" type="text" placeholder="نام کاربری" maxlength="16" required><br />
        <input type="text" name="form[password]" placeholder="پسورد" required><br />
        <input name="btn" type="submit" value="!ورود">
        </form><br><br>

</div>
</body>
</html>