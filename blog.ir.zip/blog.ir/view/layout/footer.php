<!-- Footer -->
<section id="footer">
    <ul class="icons">
        <li><a href="#" class="icon brands fa-twitter"><span class="label">توییتر</span></a></li>
        <li><a href="#" class="icon brands fa-facebook-f"><span class="label">فیسبوک</span></a></li>
        <li><a href="#" class="icon brands fa-instagram"><span class="label">اینیستاگرام</span></a></li>
        <li><a href="#" class="icon solid fa-rss"><span class="label">فید</span></a></li>
        <li><a href="#" class="icon solid fa-envelope"><span class="label">امیل</span></a></li>
    </ul>
    <p class="copyright">&copy; طراحی توسط علیرضاکشاورز <a href="http://html5up.net">HTML5 UP</a>. Images: <a href="http://unsplash.com">Unsplash</a>.</p>
</section>

</section>

</div>
</div>
<!-- Scripts -->
<script src="public/template/assets/js/jquery.min.js"></script>
<script src="public/template/assets/js/browser.min.js"></script>
<script src="public/template/assets/js/breakpoints.min.js"></script>
<script src="public/template/assets/js/util.js"></script>
<script src="public/template/assets/js/main.js"></script>

</body>
</html>