<?php
include_once 'model/mindex.php';
include_once 'view/index/index.php';

?>