<script
        src="http://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
<style>
    .b3 {
        margin: 0 auto !important;
    }
</style>
<div class="col-md-2"></div>
<center>
    <div class="col-md-8"><br><br>

        <div class="box box-info b3">
            <div class="box-header with-border">
                <h3 class="box-title">افزودن منو</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
                <div class="box-body">
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">عنوان</label>

                        <div class="col-sm-10">
                            <input name="frm[title]" type="text" class="form-control" id="title" placeholder="عنوان"
                                   required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label name="frm[url]" for="" class="col-sm-2 control-label">آدرس منو</label>

                        <div class="col-sm-10">
                            <input type="url" class="form-control" id="url" placeholder="آدرس منو" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">ترتیب نمایش</label>

                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="sort" placeholder="ترتیب" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label"> وضعیت نمایش</label>

                        <div class="col-sm-6">
                            <select style="height: 40px" type="number" class="form-control" id="" placeholder="ترتیب">
                                <option value="1" selected>فعال</option>
                                <option value="0"> غیر فعال</option>

                            </select>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div style="    display: flex;
    justify-content: center;" class="box-footer">
                    <button style="
padding:5px 20px;font-size: 19px" type="submit" class="btn btn-info pull-right">ثبت
                    </button>
                </div>
                <!-- /.box-footer -->
            </form>
        </div>

    </div>
</center>
<div class="col-md-2"></div>
<div class="row">
    <div class="col-md-3">
        <div>
            <div class="box box-info b3">
                <div class="box-header with-border">
                    <h3 class="box-title">دسته بندی ها</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                    <div class="box-body">
                        <div style="margin: 10px 20px 10px 20px;height: 48px;" class="form-group">
                            <select style="height: 30px;width: 150px" name="" id="seleter_1">
                                <option data-url="varzesh3.ir" data-title="ورزش ۳">ورزش۳</option>
                                <option data-url="blog.ir" data-title="بلاگ">بلاگ</option>

                            </select>

                        </div>

                    </div>
                    <!-- /.box-body -->
                    <div style="    display: flex;
    justify-content: center;" class="box-footer">
                        <button id="btn" class="btn btn-info pull-right">افزودن
                        </button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div>
            <div class="box box-info b3">
                <div class="box-header with-border">
                    <h3 class="box-title">صفحات</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal">
                    <div class="box-body">
                        <div style="margin: 10px 20px 10px 20px;height: 48px;" class="form-group">
                            <select style="height: 30px;width: 150px" name="" id="seleter">
                                <option data-url="varzesh3.ir" data-title="ورزش ۳">ورزش۳</option>
                                <option data-url="blog.ir" data-title="بلاگ">بلاگ</option>

                            </select>
                        </div>

                    </div>
                    <!-- /.box-body -->
                    <div style="    display: flex;
    justify-content: center;" class="box-footer">
                        <button id="btn_1" class="btn btn-info pull-right">افزودن
                        </button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<script>
    function myRandom(start,end){
        randomNumber = start + Math.floor(Math.random() * (end-start));
        return randomNumber;
    }
$('#btn_1').click(function (e) {
    $n=myRandom(1,12);
    e.preventDefault();
$('#title').val($('#seleter option:selected').attr('data-title'));
    $('#url').val($('#seleter option:selected').attr('data-url'));
    $('#sort').val($n)

});

$('#btn').click(function (e) {
    $n=myRandom(1,12);
    e.preventDefault();
    $('#title').val($('#seleter_1 option:selected').attr('data-title'));
    $('#url').val($('#seleter option:selected').attr('data-url'));
    $('#sort').val($n)

})
</script>