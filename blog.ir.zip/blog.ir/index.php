<?php
// ----------header view------------
include_once "view/layout/header.php";
require_once 'vendor/autoload.php';
//$klein = new \Klein\Klein();
//
//$klein->respond('GET', '/user', function () {
//    header('location:admin/index.php');
////include_once  'controller/cindex.php';
//});
//header('location:admin/index.php');



//$klein->with('/admin', function () use ($klein) {
//    $klein->respond('GET', '/add', function ($request, $response) {
//        echo 'Show all uszers';
//    });
//    $klein->respond('GET', '/[:id]', function ($request, $response) {
//        // Show a single user
//    });
//
//});



// --------------footer view----------------
include_once "view/layout/footer.php";
// end footer
?>