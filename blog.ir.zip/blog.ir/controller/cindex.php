<h1>controlle cIndex</h1>
<?php
include_once 'model/mindex.php';
include_once 'view/index/index.php';

?>