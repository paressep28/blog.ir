<br><br>
<div class="col-xs-8">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">نمایش لیست دسته بندی ها</h3>
            <style>
                td input{
                    width: 130px !important;
                }
                td{
                    padding: 12px !important;
                }
            </style>

        </div>
        <!-- /.box-header -->
        <div class="box-body table-responsive no-padding">
            <table class="table table-hover">
                <tbody><tr>
                    <th>آیدی</th>
                    <th>نام</th>
                    <th>تعداد مطالب</th>


                </tr>
                <tr>
                    <td>13</td>
                    <td>ورزشی</td>
                    <td><span class="label-info label">25</span></td>


                </tr>
                <tr>
                    <td>13</td>
                    <td>ورزشی</td>
                    <td><span class="label-info label">25</span></td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>ورزشی</td>
                    <td><span class="label-info label">25</span></td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>ورزشی</td>
                    <td><span class="label-info label">25</span></td>
                </tr>
                </tbody></table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
</div>