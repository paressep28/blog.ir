
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<style>
    *{
        fon
    }
</style>
    <h2>مشاهده ی لیست دکمه ها</h2>
    <p class="alert alert-info">لیست دکمه ها به چند گرید مشخص تبدیل شده است که هر دکمه در گرید مورد نظر قرار می گیرد</p>

    <ul class="nav nav-tabs">
        <li class=""><a data-toggle="tab" href="#home">ناحیه ۱</a></li>
        <li><a data-toggle="tab" href="#menu1">ناحیه ۲</a></li>
        <li><a data-toggle="tab" href="#menu2">ناحیه ۳</a></li>
        <li><a data-toggle="tab" href="#menu3">ناحیه۴</a></li>
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in active">
            <div class="col-md-10">
                <div class="box">
                    <style>
                        .b1{
                            color: #51d02c;
                        }
                        .b2{
                            color: red;
                        }
                        img{
                            width: 24px;
                        }
                        input{
                            border: 1px silver solid;
                            padding:3px;
                            width:140px;
                            text-align: center;
                        }
                        td,th{
                            text-align: center;
                        }
                    </style>
                    <div class="box-header with-border">
                        <h3 class="box-title">نمایش لیست دکمه ها </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody><tr>
                                <th >عنوان</th>
                                <th>آدرس دکمه </th>
                                <th>ترتیب </th>
                                <th>رنگ</th>
                                <th>رنگ بردر</th>
                                <th>ناحیه</th>
                                <th>ویرایش</th>
                                <th>حذف</th>

                            </tr>
                            <?php
                            $show2=showbtn('0');
                            if($show2){
                                foreach ($show2 as $item2) {
                                    ?>
                                    <tr>
                                        <td><?php
                                            echo $item2['title'];
                                            ?></td>
                                        <td><input  type="text" value="<?php
                                            echo $item2['link'];
                                            ?>"></td>
                                        <td><?php
                                           echo $item2['sort']
                                            ?></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['color'];

                                            ?>"></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['border'];

                                            ?>"></td>
                                        <td><?php echo "ناحیه :".$x ?></td>
                                        <td><a href="dashbord.php?m=btn&p=edait&id=<?php echo $item2['id'] ?>" style="color: #39ddff" class="fa fa-2x fa-hand-pointer-o"></a></td>
                                        <td><a href="dashbord.php?m=btn&p=delete&id=<?php echo $item2['id'] ?>" style="color: #ff0008" class="fa fa-2x  fa-recycle"></a></td>

                                    </tr>
                                    <?php
                                };
                            }
                            ?>
                            </tbody></table>
                    </div>
                    <!-- /.box-body -->

                </div>
                <!-- /.box -->

                <!-- /.box -->
            </div>        </div>
        <div id="menu1" class="tab-pane fade">
            <div class="col-md-10">
                <div class="box">
                    <style>
                        .b1{
                            color: #51d02c;
                        }
                        .b2{
                            color: red;
                        }
                        img{
                            width: 24px;
                        }
                        input{
                            border: 1px silver solid;
                            padding:3px;
                            width:140px;
                            text-align: center;
                        }
                        td,th{
                            text-align: center;
                        }
                    </style>
                    <div class="box-header with-border">
                        <h3 class="box-title">نمایش لیست دکمه ها </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody><tr>
                                <th >عنوان</th>
                                <th>آدرس دکمه </th>
                                <th>ترتیب </th>
                                <th>رنگ</th>
                                <th>رنگ بردر</th>
                                <th>ناحیه</th>
                                <th>ویرایش</th>
                                <th>حذف</th>

                            </tr>
                            <?php
                            $show2=showbtn('1');
                            if($show2){
                                foreach ($show2 as $item2) {
                                    ?>
                                    <tr>
                                        <td><?php
                                            echo $item2['title'];
                                            ?></td>
                                        <td><input  type="text" value="<?php
                                            echo $item2['link'];
                                            ?>"></td>
                                        <td><?php
                                            echo $item2['sort']
                                            ?></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['color'];
                                            ?>"></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['border'];
                                            $x=$item2['grid']+1;
                                            ?>"></td>
                                        <td><?php echo "ناحیه :".$x ?></td>
                                        <td><a href="dashbord.php?m=btn&p=edait&id=<?php echo $item2['id'] ?>" style="color: #39ddff" class="fa fa-2x fa-hand-pointer-o"></a></td>
                                        <td><a href="dashbord.php?m=btn&p=delete&id=<?php echo $item2['id'] ?>" style="color: #ff0008" class="fa fa-2x  fa-recycle"></a></td>

                                    </tr>
                                    <?php
                                };
                            }
                            ?>
                            </tbody></table>
                    <!-- /.box-body -->

                </div>
                <!-- /.box -->

                <!-- /.box -->
            </div>        </div>        </div>
        <div id="menu2" class="tab-pane fade">
            <div class="col-md-10">
                <div class="box">
                    <style>
                        .b1{
                            color: #51d02c;
                        }
                        .b2{
                            color: red;
                        }
                        img{
                            width: 24px;
                        }
                        input{
                            border: 1px silver solid;
                            padding:3px;
                            width:140px;
                            text-align: center;
                        }
                        td,th{
                            text-align: center;
                        }
                    </style>
                    <div class="box-header with-border">
                        <h3 class="box-title">نمایش لیست دکمه ها </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody><tr>
                                <th >عنوان</th>
                                <th>آدرس دکمه </th>
                                <th>ترتیب </th>
                                <th>رنگ</th>
                                <th>رنگ بردر</th>
                                <th>ناحیه</th>
                                <th>ویرایش</th>
                                <th>حذف</th>

                            </tr>
                            <?php
                            $show2=showbtn('2');
                            if($show2){
                                foreach ($show2 as $item2) {
                                    ?>
                                    <tr>
                                        <td><?php
                                            echo $item2['title'];
                                            ?></td>
                                        <td><input  type="text" value="<?php
                                            echo $item2['link'];
                                            ?>"></td>
                                        <td><?php
                                            echo $item2['sort']
                                            ?></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['color'];
                                            ?>"></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['border'];
                                            $x=$item2['grid']+1;
                                            ?>"></td>
                                        <td><?php echo "ناحیه :".$x ?></td>
                                        <td><a href="dashbord.php?m=btn&p=edait&id=<?php echo $item2['id'] ?>" style="color: #39ddff" class="fa fa-2x fa-hand-pointer-o"></a></td>
                                        <td><a href="dashbord.php?m=btn&p=delete&id=<?php echo $item2['id'] ?>" style="color: #ff0008" class="fa fa-2x  fa-recycle"></a></td>

                                    </tr>
                                    <?php
                                };
                            }
                            ?>
                            </tbody></table>
                        <!-- /.box-body -->

                    </div>
                    <!-- /.box -->

                    <!-- /.box -->
                </div>        </div>
        </div>
        <div id="menu3" class="tab-pane fade">
            <div class="col-md-10">
                <div class="box">
                    <style>
                        .b1{
                            color: #51d02c;
                        }
                        .b2{
                            color: red;
                        }
                        img{
                            width: 24px;
                        }
                        input{
                            border: 1px silver solid;
                            padding:3px;
                            width:140px;
                            text-align: center;
                        }
                        td,th{
                            text-align: center;
                        }
                    </style>
                    <div class="box-header with-border">
                        <h3 class="box-title">نمایش لیست دکمه ها </h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody><tr>
                                <th >عنوان</th>
                                <th>آدرس دکمه </th>
                                <th>ترتیب </th>
                                <th> رنگه دکمه</th>
                                <th>رنگ بردر</th>
                                <th>ناحیه</th>
                                <th>ویرایش</th>
                                <th>حذف</th>

                            </tr>
                            <?php
                            $show2=showbtn('3');
                            if($show2){
                                foreach ($show2 as $item2) {
                                    ?>
                                    <tr>
                                        <td><?php
                                            echo $item2['title'];
                                            ?></td>
                                        <td><input  type="text" value="<?php
                                            echo $item2['link'];
                                            ?>"></td>
                                        <td><?php
                                            echo $item2['sort']
                                            ?></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['color'];
                                            ?>"></td>
                                        <td> <input disabled type="color" value="<?php
                                            echo $item2['border'];
                                            $x=$item2['grid']+1;
                                            ?>"></td>
                                        <td><?php echo "ناحیه :".$x ?></td>
                                        <td><a href="dashbord.php?m=btn&p=edait&id=<?php echo $item2['id'] ?>" style="color: #39ddff" class="fa fa-2x fa-hand-pointer-o"></a></td>
                                        <td><a href="dashbord.php?m=btn&p=delete&id=<?php echo $item2['id'] ?>" style="color: #ff0008" class="fa fa-2x  fa-recycle"></a></td>

                                    </tr>
                                    <?php
                                };
                            }
                            ?>
                            </tbody></table>
                        <!-- /.box-body -->

                    </div>
                    <!-- /.box -->

                    <!-- /.box -->
                </div>        </div>
        </div>
    </div>

